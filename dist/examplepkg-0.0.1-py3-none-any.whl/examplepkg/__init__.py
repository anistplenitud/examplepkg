def echo():
    print(f'This is awesome!')