from examplepkg.__init__ import *

def test():
    print("testing")